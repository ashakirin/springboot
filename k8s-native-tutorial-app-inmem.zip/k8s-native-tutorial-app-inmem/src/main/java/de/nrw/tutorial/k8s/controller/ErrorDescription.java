package de.nrw.tutorial.k8s.controller;

import lombok.Data;

@Data
public class ErrorDescription {
    private final String message;
}
