package de.nrw.tutorial.k8s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K8sNativeTutorialAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
